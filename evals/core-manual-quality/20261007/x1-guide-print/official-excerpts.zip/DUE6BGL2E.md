# DUE6BGL2E 공식 설명서 발췌 안내

**공식 원문 발췌 안내**

선택한 모델의 공식 원문을 모은 발췌 안내입니다. 전체 정식 설명서를 대체하지 않습니다. 새 조리 수치나 사용 절차를 생성하지 않았으며, 정확한 원문 범위와 문서판은 각 출처에서 확인하세요.

자료 묶음: LGE-R8-dishwasher-development-20261007-official-v1

## 실제 근거 원문 · 제안과 구분

### DUE6BGL2E 설명서: 식기 배열

출처 ID: DUE6BGL2E-MANUAL-D12

자료 범위: 일부 발췌 · 페이지 모델: DUE6BGL2E
문서판: MFL71959117 Rev.07\_030626 · 구매 모델: 미확인
게시일: 미확인

> 하단 식기 바구니에 식기 배열하기
> 하단 식기 바구니는 큰 접시, 냄비, 프라이팬, 오목한 그릇 
> 등 부피가 큰 식기를 세척하기에 좋습니다.
> 상단 식기 바구니에 식기 배열하기
> 상단 식기 바구니는 오목한 그릇, 작은 접시, 컵, 유리잔  
> 등을 세척하기에 좋습니다.
> • 컵 선반에는 컵, 작은 식기 등을 놓을 수 있습니다.
> 최상단 식기 바구니에 식기 배열하기
> 최상단 식기 바구니는 수저류, 칼, 포크 등을 세척하기에  
> 좋습니다.

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=47eEeOZ5yQ3pVzw1uosMxg)

원문 위치: \{&quot;page&quot;: 20, &quot;section&quot;: &quot;식기 배열&quot;\}

보존한 원문 사실:

- \{&quot;fact\_id&quot;: &quot;DUE6BGL2E-MANUAL-D12-fact&quot;, &quot;kind&quot;: &quot;document\_fact&quot;, &quot;locator&quot;: \{&quot;page&quot;: 20, &quot;section&quot;: &quot;식기 배열&quot;\}, &quot;text&quot;: &quot;하단 식기 바구니에 식기 배열하기\\n하단 식기 바구니는 큰 접시, 냄비, 프라이팬, 오목한 그릇 \\n등 부피가 큰 식기를 세척하기에 좋습니다.\\n상단 식기 바구니에 식기 배열하기\\n상단 식기 바구니는 오목한 그릇, 작은 접시, 컵, 유리잔  \\n등을 세척하기에 좋습니다.\\n• 컵 선반에는 컵, 작은 식기 등을 놓을 수 있습니다.\\n최상단 식기 바구니에 식기 배열하기\\n최상단 식기 바구니는 수저류, 칼, 포크 등을 세척하기에  \\n좋습니다.&quot;\}

### DUE6BGL2E 설명서: 상단 바구니 높이

출처 ID: DUE6BGL2E-MANUAL-D09

자료 범위: 일부 발췌 · 페이지 모델: DUE6BGL2E
문서판: MFL71959117 Rev.07\_030626 · 구매 모델: 미확인
게시일: 미확인

> 높이를 3단계로 조절

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=47eEeOZ5yQ3pVzw1uosMxg)

원문 위치: \{&quot;page&quot;: 23, &quot;section&quot;: &quot;상단 바구니 높이&quot;\}

보존한 원문 사실:

- \{&quot;fact\_id&quot;: &quot;DUE6BGL2E-MANUAL-D09-fact&quot;, &quot;kind&quot;: &quot;document\_fact&quot;, &quot;locator&quot;: \{&quot;page&quot;: 23, &quot;section&quot;: &quot;상단 바구니 높이&quot;\}, &quot;text&quot;: &quot;높이를 3단계로 조절&quot;\}

### DUE6BGL2E 설명서: 높이 조절 조건

출처 ID: DUE6BGL2E-MANUAL-D13

자료 범위: 일부 발췌 · 페이지 모델: DUE6BGL2E
문서판: MFL71959117 Rev.07\_030626 · 구매 모델: 미확인
게시일: 미확인

> 반드시 식기 바구니를 모두 비운 후 높이를 조절하세요.

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=47eEeOZ5yQ3pVzw1uosMxg)

원문 위치: \{&quot;page&quot;: 23, &quot;section&quot;: &quot;높이 조절 조건&quot;\}

보존한 원문 사실:

- \{&quot;fact\_id&quot;: &quot;DUE6BGL2E-MANUAL-D13-fact&quot;, &quot;kind&quot;: &quot;document\_fact&quot;, &quot;locator&quot;: \{&quot;page&quot;: 23, &quot;section&quot;: &quot;높이 조절 조건&quot;\}, &quot;text&quot;: &quot;반드시 식기 바구니를 모두 비운 후 높이를 조절하세요.&quot;\}

### DUE6BGL2E 설명서: 노즐 간섭 조건

출처 ID: DUE6BGL2E-MANUAL-D14

자료 범위: 일부 발췌 · 페이지 모델: DUE6BGL2E
문서판: MFL71959117 Rev.07\_030626 · 구매 모델: 미확인
게시일: 미확인

> 상단 식기 바구니를 먼저 밀어 넣은 후 하단 식기  
> 바구니를 밀어 넣으세요. 식기 크기가 크면 상단 노즐에 
> 닿아 잘 돌아가지 않습니다.

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=47eEeOZ5yQ3pVzw1uosMxg)

원문 위치: \{&quot;page&quot;: 24, &quot;section&quot;: &quot;노즐 간섭 조건&quot;\}

보존한 원문 사실:

- \{&quot;fact\_id&quot;: &quot;DUE6BGL2E-MANUAL-D14-fact&quot;, &quot;kind&quot;: &quot;document\_fact&quot;, &quot;locator&quot;: \{&quot;page&quot;: 24, &quot;section&quot;: &quot;노즐 간섭 조건&quot;\}, &quot;text&quot;: &quot;상단 식기 바구니를 먼저 밀어 넣은 후 하단 식기  \\n바구니를 밀어 넣으세요. 식기 크기가 크면 상단 노즐에 \\n닿아 잘 돌아가지 않습니다.&quot;\}

### DUE6BGL2E 설명서: 양쪽 높이 확인

출처 ID: DUE6BGL2E-MANUAL-D13-P24

자료 범위: 일부 발췌 · 페이지 모델: DUE6BGL2E
문서판: MFL71959117 Rev.07\_030626 · 구매 모델: 미확인
게시일: 미확인

> 식기 바구니의 양쪽 높이가 동일한지 확인한 후 제품  
> 안쪽으로 밀어 넣으세요.

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=47eEeOZ5yQ3pVzw1uosMxg)

원문 위치: \{&quot;page&quot;: 24, &quot;section&quot;: &quot;양쪽 높이 확인&quot;\}

보존한 원문 사실:

- \{&quot;fact\_id&quot;: &quot;DUE6BGL2E-MANUAL-D13-P24-fact&quot;, &quot;kind&quot;: &quot;document\_fact&quot;, &quot;locator&quot;: \{&quot;page&quot;: 24, &quot;section&quot;: &quot;양쪽 높이 확인&quot;\}, &quot;text&quot;: &quot;식기 바구니의 양쪽 높이가 동일한지 확인한 후 제품  \\n안쪽으로 밀어 넣으세요.&quot;\}

### DUE6BGL2E 설명서: 상단 바구니 없는 세척 금지

출처 ID: DUE6BGL2E-MANUAL-D14-P20

자료 범위: 일부 발췌 · 페이지 모델: DUE6BGL2E
문서판: MFL71959117 Rev.07\_030626 · 구매 모델: 미확인
게시일: 미확인

> 상단 식기 바구니를 제품에서 빼낸 상태에서 식기를  
> 세척하지 마세요.

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=47eEeOZ5yQ3pVzw1uosMxg)

원문 위치: \{&quot;page&quot;: 20, &quot;section&quot;: &quot;상단 바구니 없는 세척 금지&quot;\}

보존한 원문 사실:

- \{&quot;fact\_id&quot;: &quot;DUE6BGL2E-MANUAL-D14-P20-fact&quot;, &quot;kind&quot;: &quot;document\_fact&quot;, &quot;locator&quot;: \{&quot;page&quot;: 20, &quot;section&quot;: &quot;상단 바구니 없는 세척 금지&quot;\}, &quot;text&quot;: &quot;상단 식기 바구니를 제품에서 빼낸 상태에서 식기를  \\n세척하지 마세요.&quot;\}
