# MW23FDI 공식 설명서 발췌 안내

**공식 원문 발췌 안내**

선택한 모델의 공식 원문을 모은 발췌 안내입니다. 전체 정식 설명서를 대체하지 않습니다. 새 조리 수치나 사용 절차를 생성하지 않았으며, 정확한 원문 범위와 문서판은 각 출처에서 확인하세요.

자료 묶음: LGE-R8-microwave-development-20261007-official-v1

## 실제 근거 원문 · 제안과 구분

### MW23FDI 설명서: 출력 조절

출처 ID: MW23FDI-MANUAL-M11

자료 범위: 일부 발췌 · 페이지 모델: MW23FDI
문서판: MFL68822538 Rev.00\_120925 · 구매 모델: 미확인
게시일: 미확인

> 버튼을 누를 때마다 1000 W ~ 800 W ~ 600 W ~ 
> 400 W ~ 200 W ~ 1000 W 순으로 진행표시부에 
> 표시됩니다.

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=uTblKnUavHksC4PsafxKeQ)

원문 위치: \{&quot;page&quot;: 25, &quot;section&quot;: &quot;출력 조절&quot;\}

보존한 원문 사실:

- \{&quot;fact\_id&quot;: &quot;MW23FDI-MANUAL-M11-fact&quot;, &quot;kind&quot;: &quot;document\_fact&quot;, &quot;locator&quot;: \{&quot;page&quot;: 25, &quot;section&quot;: &quot;출력 조절&quot;\}, &quot;text&quot;: &quot;버튼을 누를 때마다 1000 W ~ 800 W ~ 600 W ~ \\n400 W ~ 200 W ~ 1000 W 순으로 진행표시부에 \\n표시됩니다.&quot;\}

### MW23FDI 설명서: 간편조리 시간

출처 ID: MW23FDI-MANUAL-M14

자료 범위: 일부 발췌 · 페이지 모델: MW23FDI
문서판: MFL68822538 Rev.00\_120925 · 구매 모델: 미확인
게시일: 미확인

> 2 문을 닫고 시작/선택  버튼을 세 번 누르세요.
> • 자동으로 조리가 시작됩니다.
> • 버튼을 누를 때마다 30초씩 올라가며

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=uTblKnUavHksC4PsafxKeQ)

원문 위치: \{&quot;page&quot;: 17, &quot;section&quot;: &quot;간편조리 시간&quot;\}

보존한 원문 사실:

- \{&quot;fact\_id&quot;: &quot;MW23FDI-MANUAL-M14-fact&quot;, &quot;kind&quot;: &quot;document\_fact&quot;, &quot;locator&quot;: \{&quot;page&quot;: 17, &quot;section&quot;: &quot;간편조리 시간&quot;\}, &quot;text&quot;: &quot;2 문을 닫고 시작/선택  버튼을 세 번 누르세요.\\n• 자동으로 조리가 시작됩니다.\\n• 버튼을 누를 때마다 30초씩 올라가며&quot;\}

### MW23FDI 설명서: 자동데우기 메뉴

출처 ID: MW23FDI-MANUAL-M15

자료 범위: 일부 발췌 · 페이지 모델: MW23FDI
문서판: MFL68822538 Rev.00\_120925 · 구매 모델: 미확인
게시일: 미확인

> 지정된 음식의 종류에 따라 조리시간이 기억되어 있어  
> 자동으로 조리됩니다.
> 1 음식물을 제품 중앙에 넣으세요.
> 2 자동요리  버튼을 한 번 눌러서 자동데우기 를  
> 선택하세요.
> 3 시작/선택  버튼을 누르면 1-1이 진행표시부에  
> 표시됩니다.
> 4 시간/무게 조절  버튼(다이얼)으로 원하는 메뉴를  
> 선택하세요.
> • \+ 버튼(다이얼): 1-1 즉석밥 ~ 1-z 국/찌개 ~  
> 1-3 우유  순으로 진행표시부에 표시됩니다.

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=uTblKnUavHksC4PsafxKeQ)

원문 위치: \{&quot;page&quot;: 18, &quot;section&quot;: &quot;자동데우기 메뉴&quot;\}

보존한 원문 사실:

- \{&quot;fact\_id&quot;: &quot;MW23FDI-MANUAL-M15-fact&quot;, &quot;kind&quot;: &quot;document\_fact&quot;, &quot;locator&quot;: \{&quot;page&quot;: 18, &quot;section&quot;: &quot;자동데우기 메뉴&quot;\}, &quot;text&quot;: &quot;지정된 음식의 종류에 따라 조리시간이 기억되어 있어  \\n자동으로 조리됩니다.\\n1 음식물을 제품 중앙에 넣으세요.\\n2 자동요리  버튼을 한 번 눌러서 자동데우기 를  \\n선택하세요.\\n3 시작/선택  버튼을 누르면 1-1이 진행표시부에  \\n표시됩니다.\\n4 시간/무게 조절  버튼(다이얼)으로 원하는 메뉴를  \\n선택하세요.\\n• \+ 버튼(다이얼): 1-1 즉석밥 ~ 1-z 국/찌개 ~  \\n1-3 우유  순으로 진행표시부에 표시됩니다.&quot;\}
