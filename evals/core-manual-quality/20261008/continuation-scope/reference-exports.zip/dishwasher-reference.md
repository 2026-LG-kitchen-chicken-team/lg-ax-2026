# 공식 참고자료 발췌 안내 · 적용 범위 확인 필요

**공식 참고자료 · 적용 범위 확인 필요**

공식 원문과 답변을 모은 참고자료입니다. 전체 정식 설명서를 대체하지 않습니다. 페이지 모델 미확인·공용 자료는 특정 구매 제품의 사용법으로 확정하지 않습니다. 문서판·참조 쪽·조건과 원문 추출 한계를 확인하세요. 참조 쪽에는 다른 절이 포함될 수 있어 같은 작업의 순서나 이어지는 단계로 확정하지 않습니다. 경우별 안내는 고객의 원인이나 실제 호전 보장이 아니며, 새 설정이나 절차를 생성하지 않았습니다.

자료 묶음: LGE-D1-D2-dishwasher-20261007-01a10600-v2-care

## 실제 근거 원문 · 제안과 구분

### 식기 배열

출처 ID: DUE6BGL2E-MANUAL-D12

자료 범위: 일부 발췌 · 페이지 모델: DUE6BGL2E
문서판: MFL71959117 Rev.07\_030626 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 선택 기능 적용 확인: retain existing SKU followup; not inferred from shared manual

> 하단 식기 바구니에 식기 배열하기
> 하단 식기 바구니는 큰 접시, 냄비, 프라이팬, 오목한 그릇 
> 등 부피가 큰 식기를 세척하기에 좋습니다.
> 상단 식기 바구니에 식기 배열하기
> 상단 식기 바구니는 오목한 그릇, 작은 접시, 컵, 유리잔  
> 등을 세척하기에 좋습니다.
> • 컵 선반에는 컵, 작은 식기 등을 놓을 수 있습니다.
> 최상단 식기 바구니에 식기 배열하기
> 최상단 식기 바구니는 수저류, 칼, 포크 등을 세척하기에  
> 좋습니다.

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=47eEeOZ5yQ3pVzw1uosMxg)

원문 위치: \{&quot;page&quot;: 20, &quot;section&quot;: &quot;식기 배열&quot;, &quot;start\_char&quot;: 454, &quot;end\_char&quot;: 692\}

보존한 원문 사실:


### 상단 바구니 높이

출처 ID: DUE6BGL2E-MANUAL-D09

자료 범위: 일부 발췌 · 페이지 모델: DUE6BGL2E
문서판: MFL71959117 Rev.07\_030626 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 선택 기능 적용 확인: retain existing SKU followup; not inferred from shared manual

> 높이를 3단계로 조절

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=47eEeOZ5yQ3pVzw1uosMxg)

원문 위치: \{&quot;page&quot;: 23, &quot;section&quot;: &quot;상단 바구니 높이&quot;, &quot;start\_char&quot;: 253, &quot;end\_char&quot;: 264\}

보존한 원문 사실:


### 높이 조절 조건

출처 ID: DUE6BGL2E-MANUAL-D13

자료 범위: 일부 발췌 · 페이지 모델: DUE6BGL2E
문서판: MFL71959117 Rev.07\_030626 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 선택 기능 적용 확인: retain existing SKU followup; not inferred from shared manual

> 반드시 식기 바구니를 모두 비운 후 높이를 조절하세요.

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=47eEeOZ5yQ3pVzw1uosMxg)

원문 위치: \{&quot;page&quot;: 23, &quot;section&quot;: &quot;높이 조절 조건&quot;, &quot;start\_char&quot;: 321, &quot;end\_char&quot;: 351\}

보존한 원문 사실:


### 노즐 간섭 조건

출처 ID: DUE6BGL2E-MANUAL-D14

자료 범위: 일부 발췌 · 페이지 모델: DUE6BGL2E
문서판: MFL71959117 Rev.07\_030626 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 선택 기능 적용 확인: retain existing SKU followup; not inferred from shared manual

> 상단 식기 바구니를 먼저 밀어 넣은 후 하단 식기  
> 바구니를 밀어 넣으세요. 식기 크기가 크면 상단 노즐에 
> 닿아 잘 돌아가지 않습니다.

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=47eEeOZ5yQ3pVzw1uosMxg)

원문 위치: \{&quot;page&quot;: 24, &quot;section&quot;: &quot;노즐 간섭 조건&quot;, &quot;start\_char&quot;: 85, &quot;end\_char&quot;: 162\}

보존한 원문 사실:


### 양쪽 높이 확인

출처 ID: DUE6BGL2E-MANUAL-D13-P24

자료 범위: 일부 발췌 · 페이지 모델: DUE6BGL2E
문서판: MFL71959117 Rev.07\_030626 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 선택 기능 적용 확인: retain existing SKU followup; not inferred from shared manual

> 식기 바구니의 양쪽 높이가 동일한지 확인한 후 제품  
> 안쪽으로 밀어 넣으세요.

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=47eEeOZ5yQ3pVzw1uosMxg)

원문 위치: \{&quot;page&quot;: 24, &quot;section&quot;: &quot;양쪽 높이 확인&quot;, &quot;start\_char&quot;: 235, &quot;end\_char&quot;: 279\}

보존한 원문 사실:


### 상단 바구니 없는 세척 금지

출처 ID: DUE6BGL2E-MANUAL-D14-P20

자료 범위: 일부 발췌 · 페이지 모델: DUE6BGL2E
문서판: MFL71959117 Rev.07\_030626 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 선택 기능 적용 확인: retain existing SKU followup; not inferred from shared manual

> 상단 식기 바구니를 제품에서 빼낸 상태에서 식기를  
> 세척하지 마세요.

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=47eEeOZ5yQ3pVzw1uosMxg)

원문 위치: \{&quot;page&quot;: 20, &quot;section&quot;: &quot;상단 바구니 없는 세척 금지&quot;, &quot;start\_char&quot;: 185, &quot;end\_char&quot;: 224\}

보존한 원문 사실:


### 스펙 / 제품 사이즈; 설명서 p57 DUE 빌트인 열

출처 ID: DATA003-DUE6BGL2E-D03

자료 범위: 일부 발췌 · 페이지 모델: DUE6BGL2E
문서판: MFL71959117 Rev.07\_030626 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 선택 기능 적용 확인: retain existing SKU followup; not inferred from shared manual

> 모델명 DFE6\*\*E, DFE6\*\*\*E DUE6\*\*E, DUE6\*\*\*E, DUE6\*\*\*\*E, 
> DEE6\*\*E
> 제품 타입 프리스탠딩 빌트인
> 전원 220 V, 60 Hz
> 최대 용량 14인용
> 수압 0.05 MPa ~ 1.0 MPa
> 소비 전력 1600 W
> 제품 크기
> (폭 X 높이 X 깊이)
> 598 mm X 845 mm X 600 mm
> 598 mm X 815 mm X 567 mm (상판 제거 시) 598 mm X 815 mm X 567 mm

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=47eEeOZ5yQ3pVzw1uosMxg)

원문 위치: \{&quot;page&quot;: 57, &quot;section&quot;: &quot;스펙 / 제품 사이즈; 설명서 p57 DUE 빌트인 열&quot;, &quot;start\_char&quot;: 574, &quot;end\_char&quot;: 817\}

보존한 원문 사실:


### \[LG 디오스 식기세척기\] 다양한 식기 수납 방법 및 주의 사항

출처 ID: D2-DW-FAQ-20152386141225

자료 범위: 일부 발췌 · 페이지 모델: 미확인
문서판: 미확인 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 페이지 모델 미확인 · 정확 구매 모델/판본·선택 기능 적용 확인 필요
- SKU 적용 확인: unverified\_common\_content
- 조건과 한계: 식기 재질, 물살과 노즐 간섭, 상단 바구니 좌우 높이 조건을 구분한다. 기능 존재가 모든 적재 불편 해결을 뜻하지 않는다.

> 식기를 수납할 때는 식기가 서로 겹치지 않도록 수납해 주세요.

[공개 원문 출처](https://www.lge.co.kr/support/solutions-20152386141225)

원문 위치: \{&quot;page&quot;: null, &quot;section&quot;: &quot;식기 수납 방법&quot;\}

보존한 원문 사실:


### \[LG 디오스 식기세척기\] 식기세척기 설치 가이드

출처 ID: D2-DW-INSTALL-1289439192281

자료 범위: 일부 발췌 · 페이지 모델: 미확인
문서판: 미확인 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 페이지 모델 미확인 · 정확 구매 모델/판본·선택 기능 적용 확인 필요
- SKU 적용 확인: unverified\_common\_content
- 조건과 한계: 빌트인·프리스탠딩 겸용·카운터탑 설명을 같은 SKU에 합치지 않는다. DUE6BGL2E는 정확 제품 페이지의 빌트인전용 사양과 설명서58쪽을 별도로 연결한다.

> 빌트인 전용은 싱크대의 높이와 깊이에 맞게 빌트인이 가능한 모델 입니다.

[공개 원문 출처](https://www.lge.co.kr/support/solutions-1289439192281)

원문 위치: \{&quot;page&quot;: null, &quot;section&quot;: &quot;빌트인 전용&quot;\}

보존한 원문 사실:


### 설치공간 A

출처 ID: D2-DW-QA-470877-A

자료 범위: 일부 발췌 · 페이지 모델: DUE6BGL2E
문서판: 미확인 · 구매 모델: 미확인
게시일: 2026-09-29

- 작성 역할: 공식 답변
- 조건별 치수·대응 · 단일 연속 발췌와 구분: \[\{&quot;field&quot;: &quot;inside\_cabinet\_depth&quot;, &quot;value&quot;: 600, &quot;unit&quot;: &quot;mm&quot;, &quot;condition&quot;: &quot;manufacturer standard installation response&quot;\}, \{&quot;field&quot;: &quot;space\_in\_front\_when\_door\_opens&quot;, &quot;value&quot;: 590, &quot;unit&quot;: &quot;mm&quot;, &quot;condition&quot;: &quot;not cabinet depth; separate dimension&quot;\}, \{&quot;field&quot;: &quot;conditional\_inside\_cabinet\_depth&quot;, &quot;min&quot;: 567, &quot;max&quot;: 600, &quot;unit&quot;: &quot;mm&quot;, &quot;condition&quot;: &quot;possible pipe compression; installation engineer must inspect; not universal approval&quot;\}\]
- 사실·조건에는 선택 발췌 바깥의 원문 대조가 포함되며, 하나의 연속 인용으로 표시하지 않습니다.

> 해당 제품 설치 시 싱크대 안쪽 깊이는 600mm가 필요하며

[공개 원문 출처](https://www.lge.co.kr/model/qna/qna-detail?modelId=MD10492836&questionNo=470877)

원문 위치: \{&quot;question\_id&quot;: &quot;470877&quot;, &quot;role&quot;: &quot;official\_answer&quot;\}

보존한 원문 사실:

- \{&quot;fact\_id&quot;: &quot;D2-DW-QA-470877-A-depth&quot;, &quot;kind&quot;: &quot;document\_fact&quot;, &quot;text&quot;: &quot;600mm&quot;, &quot;value&quot;: 600, &quot;unit&quot;: &quot;mm&quot;, &quot;locator&quot;: \{&quot;answer\_paragraph&quot;: 1, &quot;measurement&quot;: &quot;inside cabinet depth&quot;\}\}
- \{&quot;fact\_id&quot;: &quot;D2-DW-QA-470877-A-door&quot;, &quot;kind&quot;: &quot;document\_fact&quot;, &quot;text&quot;: &quot;590mm&quot;, &quot;value&quot;: 590, &quot;unit&quot;: &quot;mm&quot;, &quot;locator&quot;: \{&quot;answer\_paragraph&quot;: 2, &quot;measurement&quot;: &quot;space in front when door opens&quot;\}\}
- \{&quot;fact\_id&quot;: &quot;D2-DW-QA-470877-A-conditional&quot;, &quot;kind&quot;: &quot;document\_fact&quot;, &quot;text&quot;: &quot;567~600mm&quot;, &quot;value&quot;: &quot;567~600&quot;, &quot;unit&quot;: &quot;mm&quot;, &quot;locator&quot;: \{&quot;answer\_paragraph&quot;: 3, &quot;condition&quot;: &quot;pipe compression possible; installation engineer inspection required, not universal approval&quot;\}\}

### • 청소할 때는

출처 ID: D2-DUE-CARE-DW-CLEAN-SAFETY-P05

자료 범위: 일부 발췌 · 페이지 모델: 미확인
문서판: MFL71959117 Rev.07\_030626 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 페이지 모델 미확인 · 정확 구매 모델/판본·선택 기능 적용 확인 필요
- 적용 범위: shared DUE6 manual; exact purchased SKU/purchase-time revision unverified
- 출처 사용 범위: \[&quot;array/nozzle interference chapters are not cleaning or odor instructions&quot;, &quot;condition-specific guidance is not a diagnosis of this customer or a recovery guarantee&quot;\]

> • 청소할 때는 전원 플러그를 전원 콘센트에서 빼세요.
> 제품을 사용할 때
> 금지 사항
> • 제품의 문이나 상부에 올라가거나 내부에 들어가지 마세요. 특히 어린이는 조심시켜 
> 주세요.
> • 제품의 내부 건조를 위해 드라이기를 사용하거나 냄새 제거를 위해 촛불을 넣지 마세요.
> • 표면이 거칠거나 금속 재질로 된 솔, 헝겊, 수세미 등으로 제품을 청소하지 마세요.
> • 화기(양초, 램프 등), 인화성 물질(LP가스, 가연성 스프레이, 살충제, 방향제 등의 가연성 
> 가스 및 에틸에테르, 벤젠, 알코올, 휘발유, 경유, 화장품 등)을 제품 근처에서 사용하거나, 
> 제품 근처에 보관하거나, 제품에 넣지 마세요.
> • 송곳 또는 핀 등 날카로운 물건으로 버튼을 누르지 마세요.
> • 청소 시 제품에 물을 직접 뿌리지 마세요.
> • 제품 위에 촛불, 담뱃불, 모기향 등을 올려놓지 마세요.
> • 열풍기는 뜨거우니 만지지 마세요. (열풍기가 있는 모델에 한함.)

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=47eEeOZ5yQ3pVzw1uosMxg)

원문 위치: \{&quot;page&quot;: 5, &quot;printed\_page&quot;: 5, &quot;section&quot;: &quot;• 청소할 때는&quot;, &quot;start\_char&quot;: 239, &quot;end\_char&quot;: 722, &quot;native\_parser&quot;: &quot;PDFium&quot;\}

보존한 원문 사실:


### 내부 청소하기

출처 ID: D2-DUE-CARE-DW-INTERNAL-CLEAN-P39

자료 범위: 일부 발췌 · 페이지 모델: 미확인
문서판: MFL71959117 Rev.07\_030626 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 페이지 모델 미확인 · 정확 구매 모델/판본·선택 기능 적용 확인 필요
- 적용 범위: shared DUE6 manual; exact purchased SKU/purchase-time revision unverified
- 자료에 표시된 참조 쪽 · 같은 절/단계 미확인: \[40\]
- 출처 사용 범위: \[&quot;array/nozzle interference chapters are not cleaning or odor instructions&quot;, &quot;condition-specific guidance is not a diagnosis of this customer or a recovery guarantee&quot;\]

> 내부 청소하기
> 부드러운 천에 물을 적셔 제품 내부를 닦으세요.
> 주의
> • 제품에 인화성 물질(알코올, 시너(신나), 벤젠 등)이나 
> 치약, 연마제, 락스 등을 뿌려 닦지 마세요. 제품 손상의 
> 원인이 됩니다.

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=47eEeOZ5yQ3pVzw1uosMxg)

원문 위치: \{&quot;page&quot;: 39, &quot;printed\_page&quot;: 39, &quot;section&quot;: &quot;내부 청소하기&quot;, &quot;start\_char&quot;: 261, &quot;end\_char&quot;: 383, &quot;native\_parser&quot;: &quot;PDFium&quot;\}

보존한 원문 사실:


### 음식물 거름 필터 청소하기

출처 ID: D2-DUE-CARE-DW-FOOD-FILTER-P39

자료 범위: 일부 발췌 · 페이지 모델: 미확인
문서판: MFL71959117 Rev.07\_030626 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 페이지 모델 미확인 · 정확 구매 모델/판본·선택 기능 적용 확인 필요
- 적용 범위: shared DUE6 manual; exact purchased SKU/purchase-time revision unverified
- 자료에 표시된 참조 쪽 · 같은 절/단계 미확인: \[40\]
- 출처 사용 범위: \[&quot;array/nozzle interference chapters are not cleaning or odor instructions&quot;, &quot;condition-specific guidance is not a diagnosis of this customer or a recovery guarantee&quot;\]

> 음식물 거름 필터 청소하기
> 음식물 찌꺼기로 인해 필터가 막히면 배수가 되지 않을 수 
> 있습니다. 필터를 청소하세요.
> 1 제품 문을 열고 하단 식기 바구니를 꺼내세요.
> 2 제품 내부 바닥에 있는 필터 a 를 반시계 방향으로 
> 돌린 후 꺼내세요.
> 알아두기
> • 배수관으로부터 역류하는 냄새를 차단하기 위해 제품 
> 하단에 일정량의 물이 차 있습니다.
> • 다음 세척 코스 진행 시 남아있던 물이 배수된 후 최초 
> 급수를 진행합니다.
> 3 일반 필터 b 와 스테인리스 필터 c 를 조심히 
> 분리하세요.
> 주의
> • 스테인리스 필터를 다룰 때 날카로운 모서리에 
> 주의하세요.

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=47eEeOZ5yQ3pVzw1uosMxg)

원문 위치: \{&quot;page&quot;: 39, &quot;printed\_page&quot;: 39, &quot;section&quot;: &quot;음식물 거름 필터 청소하기&quot;, &quot;start\_char&quot;: 383, &quot;end\_char&quot;: 709, &quot;native\_parser&quot;: &quot;PDFium&quot;\}

보존한 원문 사실:


### 4 부드러운 솔로

출처 ID: D2-DUE-CARE-DW-FOOD-FILTER-P40

자료 범위: 일부 발췌 · 페이지 모델: 미확인
문서판: MFL71959117 Rev.07\_030626 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 페이지 모델 미확인 · 정확 구매 모델/판본·선택 기능 적용 확인 필요
- 적용 범위: shared DUE6 manual; exact purchased SKU/purchase-time revision unverified
- 자료에 표시된 참조 쪽 · 같은 절/단계 미확인: \[39\]
- 출처 사용 범위: \[&quot;array/nozzle interference chapters are not cleaning or odor instructions&quot;, &quot;condition-specific guidance is not a diagnosis of this customer or a recovery guarantee&quot;\]

> 4 부드러운 솔로 필터에 묻어 있는 음식물 찌꺼기를 
> 제거하고 흐르는 물에 씻으세요.
> 5 일반 필터와 스테인리스 필터를 재조립하고 원래 있던 
> 자리에 넣은 후 시계 방향으로 &\#x27;딸깍&\#x27; 소리가 날 때까지 
> 돌리세요.
> 6 하단 식기 바구니를 원래 있던 자리에 넣으세요.
> 주의
> • 필터를 청소하지 않으면 필터 내의 음식물 찌꺼기 
> 때문에 악취가 나거나 세척 성능이 저하될 수 있습니다.

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=47eEeOZ5yQ3pVzw1uosMxg)

원문 위치: \{&quot;page&quot;: 40, &quot;printed\_page&quot;: 40, &quot;section&quot;: &quot;4 부드러운 솔로&quot;, &quot;start\_char&quot;: 9, &quot;end\_char&quot;: 230, &quot;native\_parser&quot;: &quot;PDFium&quot;\}

보존한 원문 사실:


### 세척조 청소하기

출처 ID: D2-DUE-CARE-DW-TUB-CITRIC-P41

자료 범위: 일부 발췌 · 페이지 모델: 미확인
문서판: MFL71959117 Rev.07\_030626 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 페이지 모델 미확인 · 정확 구매 모델/판본·선택 기능 적용 확인 필요
- 적용 범위: shared DUE6 manual; exact purchased SKU/purchase-time revision unverified
- 자료에 표시된 참조 쪽 · 같은 절/단계 미확인: \[42\]
- 출처 사용 범위: \[&quot;array/nozzle interference chapters are not cleaning or odor instructions&quot;, &quot;condition-specific guidance is not a diagnosis of this customer or a recovery guarantee&quot;\]

> 세척조 청소하기
> 구연산이나 식초를 사용하여 제품 내부의 음식물 찌꺼기, 
> 냄새, 얼룩을 제거하고, 변색된 부분을 되돌릴 수 있습니다.
> • 제품 내부에 흰 얼룩이나 흰 가루는 물 속에 있는 
> 칼슘이나 마그네슘 등의 석회 성분이 남아서 생기는 
> 현상입니다. 지하수를 사용하거나 석회 성분이 많은 
> 지역에서 발생할 수 있습니다.
> 알아두기
> • 세척조를 청소할 때는 세제가 필요 없습니다.
> 구연산을 사용하여 청소하기
> 구연산을 사용할 때는 다음과 같이 세척조를 청소하세요.
> 1 제품 내부를 비우세요.
> 2 세제 투입구에 구연산 분말을 가득 넣으세요.
> 3 전원 a 버튼을 눌러 제품을 켜세요.
> 4 LG ThinQ 앱에서 통살균 코스를 다운받은 후 
> 다운로드 b 버튼을 눌러 다운로드 코스 (P13)를 
> 선택하세요.
> 5 시작 c 또는 시작/정지 c 버튼을 누르면 세척조 
> 청소가 시작됩니다.

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=47eEeOZ5yQ3pVzw1uosMxg)

원문 위치: \{&quot;page&quot;: 41, &quot;printed\_page&quot;: 41, &quot;section&quot;: &quot;세척조 청소하기&quot;, &quot;start\_char&quot;: 536, &quot;end\_char&quot;: 989, &quot;native\_parser&quot;: &quot;PDFium&quot;\}

보존한 원문 사실:


### 식초를 사용하여 청소하기

출처 ID: D2-DUE-CARE-DW-TUB-VINEGAR-P41

자료 범위: 일부 발췌 · 페이지 모델: 미확인
문서판: MFL71959117 Rev.07\_030626 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 페이지 모델 미확인 · 정확 구매 모델/판본·선택 기능 적용 확인 필요
- 적용 범위: shared DUE6 manual; exact purchased SKU/purchase-time revision unverified
- 자료에 표시된 참조 쪽 · 같은 절/단계 미확인: \[42\]
- 출처 사용 범위: \[&quot;array/nozzle interference chapters are not cleaning or odor instructions&quot;, &quot;condition-specific guidance is not a diagnosis of this customer or a recovery guarantee&quot;\]

> 식초를 사용하여 청소하기
> 식초를 사용할 때는 다음과 같이 세척조를 청소하세요.
> 1 제품 내부를 비우세요.

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=47eEeOZ5yQ3pVzw1uosMxg)

원문 위치: \{&quot;page&quot;: 41, &quot;printed\_page&quot;: 41, &quot;section&quot;: &quot;식초를 사용하여 청소하기&quot;, &quot;start\_char&quot;: 989, &quot;end\_char&quot;: 1049, &quot;native\_parser&quot;: &quot;PDFium&quot;\}

보존한 원문 사실:


### 2 상단 식기 바구니 중앙

출처 ID: D2-DUE-CARE-DW-TUB-VINEGAR-P42

자료 범위: 일부 발췌 · 페이지 모델: 미확인
문서판: MFL71959117 Rev.07\_030626 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 페이지 모델 미확인 · 정확 구매 모델/판본·선택 기능 적용 확인 필요
- 적용 범위: shared DUE6 manual; exact purchased SKU/purchase-time revision unverified
- 자료에 표시된 참조 쪽 · 같은 절/단계 미확인: \[41, 43\]
- 출처 사용 범위: \[&quot;array/nozzle interference chapters are not cleaning or odor instructions&quot;, &quot;condition-specific guidance is not a diagnosis of this customer or a recovery guarantee&quot;\]

> 2 상단 식기 바구니 중앙에 식초 200 ml ~ 300 ml 를 담은 
> 그릇을 넣으세요.
> 3 전원 a 버튼을 눌러 제품을 켜세요.
> 4 LG ThinQ 앱에서 통살균 코스를 다운받은 후 
> 다운로드 b 버튼을 눌러 다운로드 코스 (P13)를 
> 선택하세요.
> 5 시작 c 또는 시작/정지 c 버튼을 누르면 세척조 
> 청소가 시작됩니다.
> 알아두기
> • 제품 내부에 식초를 직접 붓거나 과도하게 사용하면 
> 제품이 손상될 수 있습니다.
> • 그릇에 뜨거운 물이 남아있으니 꺼낼 때 조심하세요.

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=47eEeOZ5yQ3pVzw1uosMxg)

원문 위치: \{&quot;page&quot;: 42, &quot;printed\_page&quot;: 42, &quot;section&quot;: &quot;2 상단 식기 바구니 중앙&quot;, &quot;start\_char&quot;: 9, &quot;end\_char&quot;: 288, &quot;native\_parser&quot;: &quot;PDFium&quot;\}

보존한 원문 사실:


### 노즐 청소하기

출처 ID: D2-DUE-CARE-DW-NOZZLE-P42

자료 범위: 일부 발췌 · 페이지 모델: 미확인
문서판: MFL71959117 Rev.07\_030626 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 페이지 모델 미확인 · 정확 구매 모델/판본·선택 기능 적용 확인 필요
- 적용 범위: shared DUE6 manual; exact purchased SKU/purchase-time revision unverified
- 자료에 표시된 참조 쪽 · 같은 절/단계 미확인: \[41, 43\]
- 출처 사용 범위: \[&quot;array/nozzle interference chapters are not cleaning or odor instructions&quot;, &quot;condition-specific guidance is not a diagnosis of this customer or a recovery guarantee&quot;\]

> 노즐 청소하기
> 노즐 구멍에 음식물 찌꺼기가 끼면 세척 효과가 
> 떨어집니다. 노즐을 청소하세요.
> 하단 노즐 청소하기
> 1 노즐 구멍에 음식물 찌꺼기가 끼어 있는지 확인하세요.
> 2 핀과 같은 뾰족한 도구를 사용하여 노즐 구멍을 막고 
> 있는 음식물 찌꺼기를 제거하세요.
> 주의
> • 고정된 노즐을 강제로 당기거나 회전시키지 마세요. 
> 파손의 원인이 됩니다.
> 상단 노즐 청소하기
> 1 노즐 구멍에 음식물 찌꺼기가 끼어 있는지 확인하세요.
> 2 상단 식기 바구니를 꺼내고 노즐 아래 부분의 너트 a
> 를 반시계 방향으로 돌린 후 아래로 당겨 분리하세요.
> 3 분리한 노즐에 물을 넣고 흔들어 음식물 찌꺼기를 
> 제거하세요.
> 4 노즐 구멍이 막혀있으면 핀과 같은 뾰족한 도구를 
> 사용하여 음식물 찌꺼기를 제거하세요.
> 5 노즐에 음식물 찌꺼기가 남아있으면 한 번 더 물을 넣고 
> 흔들어 음식물 찌꺼기를 제거하세요.

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=47eEeOZ5yQ3pVzw1uosMxg)

원문 위치: \{&quot;page&quot;: 42, &quot;printed\_page&quot;: 42, &quot;section&quot;: &quot;노즐 청소하기&quot;, &quot;start\_char&quot;: 288, &quot;end\_char&quot;: 747, &quot;native\_parser&quot;: &quot;PDFium&quot;\}

보존한 원문 사실:


### 6 상단 노즐을

출처 ID: D2-DUE-CARE-DW-NOZZLE-P43

자료 범위: 일부 발췌 · 페이지 모델: 미확인
문서판: MFL71959117 Rev.07\_030626 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 페이지 모델 미확인 · 정확 구매 모델/판본·선택 기능 적용 확인 필요
- 적용 범위: shared DUE6 manual; exact purchased SKU/purchase-time revision unverified
- 자료에 표시된 참조 쪽 · 같은 절/단계 미확인: \[42\]
- 출처 사용 범위: \[&quot;array/nozzle interference chapters are not cleaning or odor instructions&quot;, &quot;condition-specific guidance is not a diagnosis of this customer or a recovery guarantee&quot;\]

> 6 상단 노즐을 원래 있던 자리에 두고 너트 b 를 시계 
> 방향으로 돌려 조립하세요.
> • 조립 후 상단 노즐이 부드럽게 회전하는지 
> 확인하세요.

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=47eEeOZ5yQ3pVzw1uosMxg)

원문 위치: \{&quot;page&quot;: 43, &quot;printed\_page&quot;: 43, &quot;section&quot;: &quot;6 상단 노즐을&quot;, &quot;start\_char&quot;: 9, &quot;end\_char&quot;: 94, &quot;native\_parser&quot;: &quot;PDFium&quot;\}

보존한 원문 사실:


### 제품 보관하기

출처 ID: D2-DUE-CARE-DW-STORAGE-P43

자료 범위: 일부 발췌 · 페이지 모델: 미확인
문서판: MFL71959117 Rev.07\_030626 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 페이지 모델 미확인 · 정확 구매 모델/판본·선택 기능 적용 확인 필요
- 적용 범위: shared DUE6 manual; exact purchased SKU/purchase-time revision unverified
- 자료에 표시된 참조 쪽 · 같은 절/단계 미확인: \[42\]
- 원문 숫자·단위 주의: native 50 7 is corrupted; audit visually verified 50°C, do not claim automatic extraction of 50°C
- 출처 사용 범위: \[&quot;array/nozzle interference chapters are not cleaning or odor instructions&quot;, &quot;condition-specific guidance is not a diagnosis of this customer or a recovery guarantee&quot;\]

> 제품 보관하기
> • 냄새 방지를 위해 필터, 세척조 및 세제통 등을 
> 청소하세요.
> • 제품을 오래 사용하지 않고 보관해야 할 경우
> - 수도꼭지를 잠그세요.
> - 전원 플러그를 뽑으세요.
> - 필터를 분리한 다음 마른 천으로 남아있는 물기를 
> 닦으세요.
> • 제품을 실외에 보관하면 겨울철 급수 호스와 배수 
> 호스가 얼어붙을 수 있습니다. 급수 호스와 배수 호스를 
> 50 7의 물로 녹인 후 사용하세요.

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=47eEeOZ5yQ3pVzw1uosMxg)

원문 위치: \{&quot;page&quot;: 43, &quot;printed\_page&quot;: 43, &quot;section&quot;: &quot;제품 보관하기&quot;, &quot;start\_char&quot;: 94, &quot;end\_char&quot;: 324, &quot;native\_parser&quot;: &quot;PDFium&quot;\}

보존한 원문 사실:


### 제품에서 냄새가 나요.

출처 ID: D2-DUE-CARE-DW-ODOR-DEVICE-P49

자료 범위: 일부 발췌 · 페이지 모델: 미확인
문서판: MFL71959117 Rev.07\_030626 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 페이지 모델 미확인 · 정확 구매 모델/판본·선택 기능 적용 확인 필요
- 적용 범위: shared DUE6 manual; exact purchased SKU/purchase-time revision unverified
- 출처 사용 범위: \[&quot;array/nozzle interference chapters are not cleaning or odor instructions&quot;, &quot;condition-specific guidance is not a diagnosis of this customer or a recovery guarantee&quot;\]

> 제품에서 냄새가 나요. 제품을 처음 사용했나요?
> • 사용 초기에는 제품에서 세척 모터 등의 전기 부품 특유의 냄새가 날 수 있습니다. 
> 제품을 1회 ~ 2회 정도 사용하면 냄새가 줄어듭니다.
> • 제품에 아스콘이 사용되지 않습니다.
> 제품을 장기간 사용하지 않았나요?
> • 밀폐된 공간에서 음식물 냄새, 잔수 등으로 인해 악취가 날 수 있습니다. 제품 
> 관리하기의 세척조 청소하기를 참고하여 냄새를 제거하세요.
> 세척하지 않은 식기를 제품에 장기간 보관했나요?
> • 식기를 식기 세척기에 장기간 보관하지 말고 바로 세척하세요.
> • 자동 문열림 기능을 사용하여 제품 내부의 공기를 순환시키세요.
> 세척조에 잔수가 많나요?
> • 80 ml ~ 100 ml보다 많은 경우, 제품의 전원을 켜고 전원 버튼을 3초간 눌러 취소
> 옵션을 선택하면 물을 배수할 수 있습니다. 제품 관리하기의 세척조 청소하기를 
> 참고하여 음식물 찌꺼기, 냄새 또는 얼룩을 제거하세요.
> 제품 내부의 바닥에 음식 찌꺼기가 있나요?
> • 제품 관리하기를 참고하여 제품 내부를 청소하거나 필터를 청소하세요.

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=47eEeOZ5yQ3pVzw1uosMxg)

원문 위치: \{&quot;page&quot;: 49, &quot;printed\_page&quot;: 49, &quot;section&quot;: &quot;제품에서 냄새가 나요.&quot;, &quot;start\_char&quot;: 534, &quot;end\_char&quot;: 1084, &quot;native\_parser&quot;: &quot;PDFium&quot;\}

보존한 원문 사실:


### 세척 후 비린내가 나요.

출처 ID: D2-DUE-CARE-DW-ODOR-FISHY-P49

자료 범위: 일부 발췌 · 페이지 모델: 미확인
문서판: MFL71959117 Rev.07\_030626 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 페이지 모델 미확인 · 정확 구매 모델/판본·선택 기능 적용 확인 필요
- 적용 범위: shared DUE6 manual; exact purchased SKU/purchase-time revision unverified
- 출처 사용 범위: \[&quot;array/nozzle interference chapters are not cleaning or odor instructions&quot;, &quot;condition-specific guidance is not a diagnosis of this customer or a recovery guarantee&quot;\]

> 세척 후 비린내가 나요. 물비린내가 나나요?
> • 일부 세제가 가진 특유의 향을 물비린내로 느낄 수 있습니다. 구매평을 확인하여 
> 세제를 변경하세요.
> 어패류, 간유, 젤라틴, 치즈, 계란 등이 묻은 식기를 세척했나요?
> • 어패류, 간유, 젤라틴, 치즈, 계란 등에 함유된 트리메틸아민은 염기성 성분으로 산성이 
> 주 성분인 세제가 냄새를 중화시켜 주지만 세제의 성분 차이로 인해 냄새가 날 수 
> 있습니다.
> • 계란이나 생선 요리를 한 후에는 먼저 식기를 애벌 세척하고 식기 바구니에 식기를 
> 수납하세요.
> • 세제 또는 린스를 변경해서 사용하세요.
> • 제품 관리하기의 세척조 청소하기를 참고하여 냄새를 제거하세요.
> 증상 원인 및 해결책

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=47eEeOZ5yQ3pVzw1uosMxg)

원문 위치: \{&quot;page&quot;: 49, &quot;printed\_page&quot;: 49, &quot;section&quot;: &quot;세척 후 비린내가 나요.&quot;, &quot;start\_char&quot;: 1084, &quot;end\_char&quot;: 1447, &quot;native\_parser&quot;: &quot;PDFium&quot;\}

보존한 원문 사실:


### 세척이 잘 되지 않아요.

출처 ID: D2-DUE-CARE-DW-POOR-CLEANING-P50

자료 범위: 일부 발췌 · 페이지 모델: 미확인
문서판: MFL71959117 Rev.07\_030626 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 페이지 모델 미확인 · 정확 구매 모델/판본·선택 기능 적용 확인 필요
- 적용 범위: shared DUE6 manual; exact purchased SKU/purchase-time revision unverified
- 출처 사용 범위: \[&quot;array/nozzle interference chapters are not cleaning or odor instructions&quot;, &quot;condition-specific guidance is not a diagnosis of this customer or a recovery guarantee&quot;\]

> 세척이 잘 되지 않아요. 식기세척기에 적합하지 않은 식기를 사용했나요?
> • 사용 전 알아두기의 식기세척기로 세척하기 부적합한 식기류를 참고하세요.
> 식기가 서로 겹쳐 있나요?
> • 식기의 배열에 따라 세척 성능에 차이가 있습니다. 식기 바구니 사용하기를 참고하여 
> 식기를 배열하세요.
> 식기 바구니에 넣은 식기가 노즐에 걸리나요?
> • 제품 작동을 멈춘 후 제품 문을 열어 식기가 노즐에 부딪히지 않도록 다시 배열하세요.
> 노즐 구멍이 막혀 있나요?
> • 제품 관리하기의 노즐 청소하기를 참고하여 노즐을 청소하세요.
> 필터가 막혀 있나요?
> • 제품 관리하기의 필터 청소하기를 참고하여 필터와 필터 주변 이물질을 제거하세요.

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=47eEeOZ5yQ3pVzw1uosMxg)

원문 위치: \{&quot;page&quot;: 50, &quot;printed\_page&quot;: 50, &quot;section&quot;: &quot;세척이 잘 되지 않아요.&quot;, &quot;start\_char&quot;: 37, &quot;end\_char&quot;: 390, &quot;native\_parser&quot;: &quot;PDFium&quot;\}

보존한 원문 사실:


### 노즐이 부드럽게 돌아가지

출처 ID: D2-DUE-CARE-DW-NOZZLE-DIAG-P48

자료 범위: 일부 발췌 · 페이지 모델: 미확인
문서판: MFL71959117 Rev.07\_030626 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 페이지 모델 미확인 · 정확 구매 모델/판본·선택 기능 적용 확인 필요
- 적용 범위: shared DUE6 manual; exact purchased SKU/purchase-time revision unverified
- 출처 사용 범위: \[&quot;array/nozzle interference chapters are not cleaning or odor instructions&quot;, &quot;condition-specific guidance is not a diagnosis of this customer or a recovery guarantee&quot;\]

> 노즐이 부드럽게 돌아가지 
> 않아요.
> 노즐 구멍이 막혀 있나요?
> • 제품 관리하기의 노즐 청소하기를 참고하여 노즐을 청소하세요.

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=47eEeOZ5yQ3pVzw1uosMxg)

원문 위치: \{&quot;page&quot;: 48, &quot;printed\_page&quot;: 48, &quot;section&quot;: &quot;노즐이 부드럽게 돌아가지&quot;, &quot;start\_char&quot;: 227, &quot;end\_char&quot;: 302, &quot;native\_parser&quot;: &quot;PDFium&quot;\}

보존한 원문 사실:

