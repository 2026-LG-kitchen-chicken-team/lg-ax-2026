# 공식 참고자료 발췌 안내 · 적용 범위 확인 필요

**공식 참고자료 · 적용 범위 확인 필요**

공식 원문과 답변을 모은 참고자료입니다. 전체 정식 설명서를 대체하지 않습니다. 페이지 모델 미확인·공용 자료는 특정 구매 제품의 사용법으로 확정하지 않습니다. 문서판·연속 페이지·조건과 원문 추출 한계를 확인하세요. 경우별 안내는 고객의 원인이나 실제 호전 보장이 아니며, 새 설정이나 절차를 생성하지 않았습니다.

자료 묶음: LGE-D1-D2-microwave-20261007-01a10600-v1

## 실제 근거 원문 · 제안과 구분

### 출력 조절

출처 ID: MW23FDI-MANUAL-M11

자료 범위: 일부 발췌 · 페이지 모델: MW23FDI
문서판: MFL68822538 Rev.00\_120925 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 선택 기능 적용 확인: retain existing SKU followup; not inferred from shared manual

> 버튼을 누를 때마다 1000 W ~ 800 W ~ 600 W ~ 
> 400 W ~ 200 W ~ 1000 W 순으로 진행표시부에 
> 표시됩니다.

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=uTblKnUavHksC4PsafxKeQ)

원문 위치: \{&quot;page&quot;: 25, &quot;section&quot;: &quot;출력 조절&quot;, &quot;start\_char&quot;: 156, &quot;end\_char&quot;: 234\}

보존한 원문 사실:


### 간편조리 시간

출처 ID: MW23FDI-MANUAL-M14

자료 범위: 일부 발췌 · 페이지 모델: MW23FDI
문서판: MFL68822538 Rev.00\_120925 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 선택 기능 적용 확인: retain existing SKU followup; not inferred from shared manual

> 2 문을 닫고 시작/선택  버튼을 세 번 누르세요.
> • 자동으로 조리가 시작됩니다.
> • 버튼을 누를 때마다 30초씩 올라가며

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=uTblKnUavHksC4PsafxKeQ)

원문 위치: \{&quot;page&quot;: 17, &quot;section&quot;: &quot;간편조리 시간&quot;, &quot;start\_char&quot;: 481, &quot;end\_char&quot;: 550\}

보존한 원문 사실:


### 자동데우기 메뉴

출처 ID: MW23FDI-MANUAL-M15

자료 범위: 일부 발췌 · 페이지 모델: MW23FDI
문서판: MFL68822538 Rev.00\_120925 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 선택 기능 적용 확인: retain existing SKU followup; not inferred from shared manual

> 지정된 음식의 종류에 따라 조리시간이 기억되어 있어  
> 자동으로 조리됩니다.
> 1 음식물을 제품 중앙에 넣으세요.
> 2 자동요리  버튼을 한 번 눌러서 자동데우기 를  
> 선택하세요.
> 3 시작/선택  버튼을 누르면 1-1이 진행표시부에  
> 표시됩니다.
> 4 시간/무게 조절  버튼(다이얼)으로 원하는 메뉴를  
> 선택하세요.
> • \+ 버튼(다이얼): 1-1 즉석밥 ~ 1-z 국/찌개 ~  
> 1-3 우유  순으로 진행표시부에 표시됩니다.

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=uTblKnUavHksC4PsafxKeQ)

원문 위치: \{&quot;page&quot;: 18, &quot;section&quot;: &quot;자동데우기 메뉴&quot;, &quot;start\_char&quot;: 8, &quot;end\_char&quot;: 246\}

보존한 원문 사실:


### 스펙·설명서 p37

출처 ID: DATA003-MW23FDI-M06

자료 범위: 일부 발췌 · 페이지 모델: MW23FDI
문서판: MFL68822538 Rev.00\_120925 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 선택 기능 적용 확인: retain existing SKU followup; not inferred from shared manual

> \*1 고주파 출력 1000 W는 짧은 시간 사용하는 경우의 출력이며, 조리 시간이 경과함에 따라 바뀔 수 있습니다 .
> 모델명 MWJ23PI, MWJ23EI, MW23FDI MWJ25PI, MWJ25EI
> 정격전압 220 V~ 60 Hz
> 정격 소비전력 1570 W
> 정격 고주파 출력 Max. 1000 W\*1

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=uTblKnUavHksC4PsafxKeQ)

원문 위치: \{&quot;page&quot;: 37, &quot;section&quot;: &quot;스펙·설명서 p37&quot;, &quot;start\_char&quot;: 189, &quot;end\_char&quot;: 358\}

보존한 원문 사실:


### 고지정보·설명서 p37

출처 ID: DATA003-MW23FDI-M07

자료 범위: 일부 발췌 · 페이지 모델: MW23FDI
문서판: MFL68822538 Rev.00\_120925 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 선택 기능 적용 확인: retain existing SKU followup; not inferred from shared manual

> 모델명 MWJ23PI, MWJ23EI, MW23FDI MWJ25PI, MWJ25EI
> 정격전압 220 V~ 60 Hz
> 정격 소비전력 1570 W

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=uTblKnUavHksC4PsafxKeQ)

원문 위치: \{&quot;page&quot;: 37, &quot;section&quot;: &quot;고지정보·설명서 p37&quot;, &quot;start\_char&quot;: 255, &quot;end\_char&quot;: 334\}

보존한 원문 사실:


### 간편 조리 출력 설정하기

출처 ID: DATA003-MW23FDI-M13

자료 범위: 일부 발췌 · 페이지 모델: MW23FDI
문서판: MFL68822538 Rev.00\_120925 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 선택 기능 적용 확인: retain existing SKU followup; not inferred from shared manual

> 간편 조리 출력 설정하기 (이 기능은 모델에 따라 다를 수  
> 있습니다.)
> • 간편 조리 출력은 기본적으로 700 W로 설정되어  
> 있습니다.
> • 간편 조리 출력은 700 W, 1000 W 2가지로 설정할 수  
> 있습니다.
> • 1000 W로 설정하려면
> 1) 문을 연 상태에서 시작/선택  버튼을 약 4초간  
> 누르면 700 W가 진행표시부에 표시됩니다.
> 2) \+ 혹은 - 버튼(다이얼)으로 1000 W를 선택하세요.
> 3) 시작/선택  버튼을 누르면 간편 조리 출력은 1000  
> W로 설정됩니다.

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=uTblKnUavHksC4PsafxKeQ)

원문 위치: \{&quot;page&quot;: 17, &quot;section&quot;: &quot;간편 조리 출력 설정하기&quot;, &quot;start\_char&quot;: 884, &quot;end\_char&quot;: 1161\}

보존한 원문 사실:


### \[LG 전자레인지\] 사용하면 안 되는 그릇(용기)는 무엇인가요?

출처 ID: D2-MW-FAQ-1332465898586

자료 범위: 일부 발췌 · 페이지 모델: 미확인
문서판: 미확인 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 페이지 모델 미확인 · 정확 구매 모델/판본·선택 기능 적용 확인 필요
- SKU 적용 확인: unverified\_common\_content
- 조건과 한계: 공용 레인지 모드 안내다. 오븐·그릴용 용기를 전자레인지 가열에 그대로 적용하지 않으며 제조사 용기 안내와 정확 모델 설명서를 함께 확인한다.

> 레인지 모드에는 금속류 그릇과 스테인리스 그릇, 뚝배기, 호일은 사용하면 안됩니다.

[공개 원문 출처](https://www.lge.co.kr/support/solutions-1332465898586)

원문 위치: \{&quot;page&quot;: null, &quot;section&quot;: &quot;더 자세히 알아볼까요?&quot;\}

보존한 원문 사실:


### \[LG 전자레인지\] 설치는 어떻게 하면 되나요

출처 ID: D2-MW-INSTALL-1410827404909

자료 범위: 일부 발췌 · 페이지 모델: 미확인
문서판: 미확인 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 페이지 모델 미확인 · 정확 구매 모델/판본·선택 기능 적용 확인 필요
- SKU 적용 확인: unverified\_common\_content
- 조건과 한계: 상부20cm·좌우/뒤10cm·바닥높이85cm는 기존 MW23FDI 설명서11쪽과 같은 값이다. 실제 설치나 통풍 성능을 측정한 결과는 아니다.

> 윗면 20cm, 측면 및 뒷면은 10cm, 바닥에서 85cm 이상 되는 위치에 설치해 주세요.

[공개 원문 출처](https://www.lge.co.kr/support/solutions-1410827404909)

원문 위치: \{&quot;page&quot;: null, &quot;section&quot;: &quot;제품 설치 시&quot;\}

보존한 원문 사실:

