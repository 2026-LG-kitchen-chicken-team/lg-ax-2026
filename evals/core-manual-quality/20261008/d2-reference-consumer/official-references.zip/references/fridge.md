# 공식 참고자료 발췌 안내 · 적용 범위 확인 필요

**공식 참고자료 · 적용 범위 확인 필요**

공식 원문과 답변을 모은 참고자료입니다. 전체 정식 설명서를 대체하지 않습니다. 페이지 모델 미확인·공용 자료는 특정 구매 제품의 사용법으로 확정하지 않습니다. 문서판·연속 페이지·조건과 원문 추출 한계를 확인하세요. 경우별 안내는 고객의 원인이나 실제 호전 보장이 아니며, 새 설정이나 절차를 생성하지 않았습니다.

자료 묶음: LGE-D1-D2-fridge-20261007-01a10600-v1

## 실제 근거 원문 · 제안과 구분

### 접이식 선반

출처 ID: T876MEE1H1-MANUAL-F08

자료 범위: 일부 발췌 · 페이지 모델: T876MEE1H1
문서판: MFL71401557 Rev.00\_032526 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 선택 기능 적용 확인: retain existing SKU followup; not inferred from shared manual

> 냉장실 접이식 선반 사용하기
> 이 기능이 적용된 모델에만 해당하는 내용입니다.
> 보관 식품의 높이와 크기에 따라 접이식 선반을 조절하여 
> 공간을 활용할 수 있습니다.

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=OKSVlmUDzoQqSyeRo6kwiw)

원문 위치: \{&quot;page&quot;: 18, &quot;section&quot;: &quot;접이식 선반&quot;, &quot;start\_char&quot;: 441, &quot;end\_char&quot;: 531\}

보존한 원문 사실:


### 선반 분리

출처 ID: T876MEE1H1-MANUAL-F10

자료 범위: 일부 발췌 · 페이지 모델: T876MEE1H1
문서판: MFL71401557 Rev.00\_032526 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 선택 기능 적용 확인: retain existing SKU followup; not inferred from shared manual

> 아랫부분을 받친 후 위로 살짝 들어 올리며 홈에서 선반 
> 고리를 빼내세요.

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=OKSVlmUDzoQqSyeRo6kwiw)

원문 위치: \{&quot;page&quot;: 19, &quot;section&quot;: &quot;선반 분리&quot;, &quot;start\_char&quot;: 7, &quot;end\_char&quot;: 48\}

보존한 원문 사실:


### 내부 청소

출처 ID: T876MEE1H1-MANUAL-F11

자료 범위: 일부 발췌 · 페이지 모델: T876MEE1H1
문서판: MFL71401557 Rev.00\_032526 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 선택 기능 적용 확인: retain existing SKU followup; not inferred from shared manual

> 내부 청소하기
> • 제품 내 구성품 분리 시 보관된 식품을 모두 꺼내세요.  
> 꺼내지 않으면 보관된 식품의 무게로 인해 다칠 수  
> 있습니다.
> • 냉장고 안의 선반이나 냉장고 문에 있는 바구니, 냉장고 
> 문의 고무 패킹은 부드러운 수건에 물을 묻혀서  
> 닦으세요.
> • 냉장고 청소 후 물기를 완전히 닦지 않으면 냉장고 안이 
> 얼 수 있으므로 물기를 완전히 제거하세요.

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=OKSVlmUDzoQqSyeRo6kwiw)

원문 위치: \{&quot;page&quot;: 21, &quot;section&quot;: &quot;내부 청소&quot;, &quot;start\_char&quot;: 1310, &quot;end\_char&quot;: 1514\}

보존한 원문 사실:


### 선반 양쪽 받치기

출처 ID: T876MEE1H1-MANUAL-F10-P18

자료 범위: 일부 발췌 · 페이지 모델: T876MEE1H1
문서판: MFL71401557 Rev.00\_032526 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 선택 기능 적용 확인: retain existing SKU followup; not inferred from shared manual

> 1 냉장실 선반을 빼낼 때는 한 손으로 냉장실 선반 한쪽의 
> 바깥부분을 잡고 다른 손으로 선반 다른 쪽의

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=OKSVlmUDzoQqSyeRo6kwiw)

원문 위치: \{&quot;page&quot;: 18, &quot;section&quot;: &quot;선반 양쪽 받치기&quot;, &quot;start\_char&quot;: 628, &quot;end\_char&quot;: 686\}

보존한 원문 사실:


### 유리 선반·식품 제거

출처 ID: T876MEE1H1-MANUAL-F10-FOOD

자료 범위: 일부 발췌 · 페이지 모델: T876MEE1H1
문서판: MFL71401557 Rev.00\_032526 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 선택 기능 적용 확인: retain existing SKU followup; not inferred from shared manual

> 유리 선반은 무거우므로 선반을 분리할때 주의하세요.
> • 선반을 분리할 때, 선반 위에 있는 식품을 치운 후  
> 분리하세요.

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=OKSVlmUDzoQqSyeRo6kwiw)

원문 위치: \{&quot;page&quot;: 19, &quot;section&quot;: &quot;유리 선반·식품 제거&quot;, &quot;start\_char&quot;: 217, &quot;end\_char&quot;: 285\}

보존한 원문 사실:


### 청소 전 플러그 분리

출처 ID: T876MEE1H1-MANUAL-F11-P05

자료 범위: 일부 발췌 · 페이지 모델: T876MEE1H1
문서판: MFL71401557 Rev.00\_032526 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 선택 기능 적용 확인: retain existing SKU followup; not inferred from shared manual

> 청소 또는 제품 실내등 교체 시에는 전원 플러그를 빼세요.

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=OKSVlmUDzoQqSyeRo6kwiw)

원문 위치: \{&quot;page&quot;: 5, &quot;section&quot;: &quot;청소 전 플러그 분리&quot;, &quot;start\_char&quot;: 488, &quot;end\_char&quot;: 520\}

보존한 원문 사실:


### 설치할 때 알아두기

출처 ID: DATA003-T876MEE1H1-F12

자료 범위: 일부 발췌 · 페이지 모델: T876MEE1H1
문서판: MFL71401557 Rev.00\_032526 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 선택 기능 적용 확인: retain existing SKU followup; not inferred from shared manual

> • 제품과 벽면 사이는 최소 10 cm의 간격을 유지하여  
> 설치하세요.
> - 냉장고와 벽 사이가 너무 가까우면 바람이 통하지  
> 않아 식품이 냉각되는 힘이 떨어집니다.
> - 냉장고 겉에 이슬이 맺힐 수 있고, 전기요금이 많이  
> 나올 수 있습니다.

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=OKSVlmUDzoQqSyeRo6kwiw)

원문 위치: \{&quot;page&quot;: 22, &quot;section&quot;: &quot;설치할 때 알아두기&quot;, &quot;start\_char&quot;: 552, &quot;end\_char&quot;: 690\}

보존한 원문 사실:


### 설치할 때 알아두기

출처 ID: DATA003-T876MEE1H1-F13

자료 범위: 일부 발췌 · 페이지 모델: T876MEE1H1
문서판: MFL71401557 Rev.00\_032526 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 선택 기능 적용 확인: retain existing SKU followup; not inferred from shared manual

> • 제품 문 위쪽과 냉장고 설치장 사이는 최소 2.5 cm의  
> 간격을 유지하여 설치하세요.

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=OKSVlmUDzoQqSyeRo6kwiw)

원문 위치: \{&quot;page&quot;: 22, &quot;section&quot;: &quot;설치할 때 알아두기&quot;, &quot;start\_char&quot;: 690, &quot;end\_char&quot;: 741\}

보존한 원문 사실:


### 냉장고 기계실 먼지와 청소 안내

출처 ID: D2-FR-FAQ-20150667060087

자료 범위: 일부 발췌 · 페이지 모델: 미확인
문서판: 미확인 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 페이지 모델 미확인 · 정확 구매 모델/판본·선택 기능 적용 확인 필요
- SKU 적용 확인: unverified\_common\_content
- 조건과 한계: 덮개 외부 먼지 제거와 전문 분해 청소를 구분한다. 청소만으로 고장 원인이 해소된다고 보장하지 않는다.

> BACK COVER(기계실 덮개)는 분리하지 마세요. 내부 냉매배관 파손 위험이 있습니다.

[공개 원문 출처](https://www.lge.co.kr/support/solutions-20150667060087)

원문 위치: \{&quot;page&quot;: null, &quot;section&quot;: &quot;주의사항&quot;\}

보존한 원문 사실:


### \[LG 냉장고 설치\] 설치할 때 벽과의 거리는 얼마를 띄워야 하나요?

출처 ID: D2-FR-INSTALL-20150708830697

자료 범위: 일부 발췌 · 페이지 모델: 미확인
문서판: 미확인 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 페이지 모델 미확인 · 정확 구매 모델/판본·선택 기능 적용 확인 필요
- SKU 적용 확인: unverified\_common\_content
- 조건과 한계: 공용 권장 간격이다. 개별 설치 공간에 대한 T876MEE1H1의 확정 판정을 대신하지 않는다.

> 일반적으로 냉장고 뒷면은 10cm, 옆면은 5cm이상의 간격을 두시는 것이 바람직합니다.

[공개 원문 출처](https://www.lge.co.kr/support/solutions-20150708830697)

원문 위치: \{&quot;page&quot;: null, &quot;section&quot;: &quot;주위와 적당한 간격을 유지해 주세요.&quot;\}

보존한 원문 사실:

