# 공식 참고자료 발췌 안내 · 적용 범위 확인 필요

**공식 참고자료 · 적용 범위 확인 필요**

공식 원문과 답변을 모은 참고자료입니다. 전체 정식 설명서를 대체하지 않습니다. 페이지 모델 미확인·공용 자료는 특정 구매 제품의 사용법으로 확정하지 않습니다. 문서판·참조 쪽·조건과 원문 추출 한계를 확인하세요. 참조 쪽에는 다른 절이 포함될 수 있어 같은 작업의 순서나 이어지는 단계로 확정하지 않습니다. 경우별 안내는 고객의 원인이나 실제 호전 보장이 아니며, 새 설정이나 절차를 생성하지 않았습니다.

자료 묶음: LGE-R9-microwave-manual-reference-20261008-v1

## 실제 근거 원문 · 제안과 구분

### 제품 청소하기: 안전·세정제 주의

출처 ID: R9-MANUAL-MW20GDN-CLEAN-P12

자료 범위: 일부 발췌 · 페이지 모델: MW20GDN
문서판: MFL71975601 Rev.06\_031126 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 적용 범위: Target base model is listed on this cover; the document can cover multiple models. Exact purchased SKU and purchase-time revision remain unverified.

> 제품 청소하기
> 주의
> • 제품을 청소하거나 손질할 때는 반드시 물기가 없는 
> 손으로 전원 플러그를 빼고 제품의 열이 식은 후에 
> 청소하세요.
> • 청소할 때 벤젠이나 시너(신나) 등을 사용하면 변색 또는 
> 변형의 원인이 되니 사용하지 마세요.
> • 표면이 거친 수세미나 철 수세미를 사용하면 제품의 
> 표면이 손상될 수 있습니다, 부드러운 천으로 된 행주를 
> 사용하세요.
> • 식초나 구연산과 같은 산성 물질은 부식이나 변형을 
> 일으킬 수 있으므로 사용 후에 마른 행주로 바로 
> 닦으세요.

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=YvbEzv4uUqAGHWDgT7CA)

원문 위치: \{&quot;page&quot;: 12, &quot;printed\_page&quot;: 12, &quot;section&quot;: &quot;제품 청소하기 / 주의&quot;, &quot;start\_char&quot;: 21, &quot;end\_char&quot;: 303, &quot;native\_parser&quot;: &quot;PDFium&quot;, &quot;char\_offset\_basis&quot;: &quot;Python code points in PDFium get\_text\_range page string&quot;\}

보존한 원문 사실:


### 제품 청소하기: 안전·세정제 주의

출처 ID: R9-MANUAL-MW30EDN-CLEAN-P12

자료 범위: 일부 발췌 · 페이지 모델: MW30EDN
문서판: MFL71975601 Rev.06\_031126 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 적용 범위: Target base model is listed on this cover; the document can cover multiple models. Exact purchased SKU and purchase-time revision remain unverified.

> 제품 청소하기
> 주의
> • 제품을 청소하거나 손질할 때는 반드시 물기가 없는 
> 손으로 전원 플러그를 빼고 제품의 열이 식은 후에 
> 청소하세요.
> • 청소할 때 벤젠이나 시너(신나) 등을 사용하면 변색 또는 
> 변형의 원인이 되니 사용하지 마세요.
> • 표면이 거친 수세미나 철 수세미를 사용하면 제품의 
> 표면이 손상될 수 있습니다, 부드러운 천으로 된 행주를 
> 사용하세요.
> • 식초나 구연산과 같은 산성 물질은 부식이나 변형을 
> 일으킬 수 있으므로 사용 후에 마른 행주로 바로 
> 닦으세요.

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=YvbEzv4uUqAGHWDgT7CA)

원문 위치: \{&quot;page&quot;: 12, &quot;printed\_page&quot;: 12, &quot;section&quot;: &quot;제품 청소하기 / 주의&quot;, &quot;start\_char&quot;: 21, &quot;end\_char&quot;: 303, &quot;native\_parser&quot;: &quot;PDFium&quot;, &quot;char\_offset\_basis&quot;: &quot;Python code points in PDFium get\_text\_range page string&quot;\}

보존한 원문 사실:


### 제품 청소하기: 안전·세정제 주의

출처 ID: R9-MANUAL-MW25B-CLEAN-P12

자료 범위: 일부 발췌 · 페이지 모델: MW25B
문서판: MFL68822540 Rev.00\_040826 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 적용 범위: Target base model is listed on this cover; the document can cover multiple models. Exact purchased SKU and purchase-time revision remain unverified.

> 제품 청소하기
> 주의
> • 제품을 청소하거나 손질할 때는 반드시 물기가 없는 
> 손으로 전원 플러그를 빼고 제품의 열이 식은 후에 
> 청소하세요.
> • 청소할 때 벤젠이나 시너(신나) 등을 사용하면 변색 또는 
> 변형의 원인이 되니 사용하지 마세요.
> • 표면이 거친 수세미나 철 수세미를 사용하면 제품의 
> 표면이 손상될 수 있습니다.
> • 식초나 구연산과 같은 산성 물질은 부식이나 변형을 
> 일으킬 수 있으므로 사용 후에 마른 행주로 바로 
> 닦으세요.

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=hsYsF0eIFyeDgjPrRrt6lA)

원문 위치: \{&quot;page&quot;: 12, &quot;printed\_page&quot;: 12, &quot;section&quot;: &quot;제품 청소하기 / 주의&quot;, &quot;start\_char&quot;: 21, &quot;end\_char&quot;: 279, &quot;native\_parser&quot;: &quot;PDFium&quot;, &quot;char\_offset\_basis&quot;: &quot;Python code points in PDFium get\_text\_range page string&quot;\}

보존한 원문 사실:


### 제품 청소하기: 안전·세정제 주의

출처 ID: R9-MANUAL-MWJ25E-CLEAN-P12

자료 범위: 일부 발췌 · 페이지 모델: MWJ25E
문서판: MFL68822525 Rev.07\_090525 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 적용 범위: Target base model is listed on this cover; the document can cover multiple models. Exact purchased SKU and purchase-time revision remain unverified.

> 제품 청소하기
> 주의
> • 제품을 청소하거나 손질할 때는 반드시 물기가 없는 
> 손으로 전원 플러그를 빼고 제품의 열이 식은 후에 
> 청소하세요.
> • 청소할 때 벤젠이나 시너(신나) 등을 사용하면 변색 또는 
> 변형의 원인이 되니 사용하지 마세요.
> • 표면이 거친 수세미나 철 수세미를 사용하면 제품의 
> 표면이 손상될 수 있습니다.
> • 식초나 구연산과 같은 산성 물질은 부식이나 변형을 
> 일으킬 수 있으므로 사용 후에 마른 행주로 바로 
> 닦으세요.

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=mEn7jHmMdCixmSM2xLC8oA)

원문 위치: \{&quot;page&quot;: 12, &quot;printed\_page&quot;: 12, &quot;section&quot;: &quot;제품 청소하기 / 주의&quot;, &quot;start\_char&quot;: 21, &quot;end\_char&quot;: 279, &quot;native\_parser&quot;: &quot;PDFium&quot;, &quot;char\_offset\_basis&quot;: &quot;Python code points in PDFium get\_text\_range page string&quot;\}

보존한 원문 사실:


### 제품 청소하기: 안전·세정제 주의

출처 ID: R9-MANUAL-MWE25HD-CLEAN-P12

자료 범위: 일부 발췌 · 페이지 모델: MWE25HD
문서판: MFL68822533 Rev.02\_030326 · 구매 모델: 미확인
게시일: 미확인

- 작성 역할: 공식 문서
- 적용 범위: Target base model is listed on this cover; the document can cover multiple models. Exact purchased SKU and purchase-time revision remain unverified.

> 제품 청소하기
> 주의
> • 제품을 청소하거나 손질할 때는 반드시 물기가 없는 
> 손으로 전원 플러그를 빼고 제품의 열이 식은 후에 
> 청소하세요.
> • 청소할 때 벤젠이나 시너(신나) 등을 사용하면 변색 또는 
> 변형의 원인이 되니 사용하지 마세요.
> • 표면이 거친 수세미나 철 수세미를 사용하면 제품의 
> 표면이 손상될 수 있습니다.
> • 식초나 구연산과 같은 산성 물질은 부식이나 변형을 
> 일으킬 수 있으므로 사용 후에 마른 행주로 바로 
> 닦으세요.

[공개 원문 출처](https://gscs-b2c.lge.com/open/downloadFile?fileId=dK5FlSmySSzQBa7TIXBuIQ)

원문 위치: \{&quot;page&quot;: 12, &quot;printed\_page&quot;: 12, &quot;section&quot;: &quot;제품 청소하기 / 주의&quot;, &quot;start\_char&quot;: 21, &quot;end\_char&quot;: 279, &quot;native\_parser&quot;: &quot;PDFium&quot;, &quot;char\_offset\_basis&quot;: &quot;Python code points in PDFium get\_text\_range page string&quot;\}

보존한 원문 사실:

